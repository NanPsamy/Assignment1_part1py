'''
Mohammad Kebbi; 1496572
Nan Ponnusamy; 1500538
'''
from graph import Graph
import binary_heap
from breadth_first_search import get_path

def least_cost_path(graph, start, dest, cost):
    """Find and return a least cost path in graph from start
    vertex to dest vertex.
    Efficiency: If E is the number of edges, the run-time is
    O( E log(E) ).
    Args:
    graph (Graph): The digraph defining the edges between the
    vertices.
    start: The vertex where the path starts. It is assumed
    that start is a vertex of graph.
    dest: The vertex where the path ends. It is assumed
    that dest is a vertex of graph.
    cost: A class with a method called "distance" that takes
    as input an edge (a pair of vertices) and returns the cost
    of the edge. For more details, see the CostDistance class
    description below.
    Returns:
    list: A potentially empty list (if no path can be found) of
    the vertices in the graph. If there was a path, the first
    vertex is always start, the last is always dest in the list.
    Any two consecutive vertices correspond to some
    edge in graph.

    """
    reached = {}  # start with an empty dictionary
    events = binary_heap.BinaryHeap()  # Create empty heap
    events.insert([start, start], 0)  # Vertex burns at time 0
    while len(events) > 0:  # While events heap is not empty
        edge, time = events.popmin()  # Pop the min from events
        if edge[1] not in reached:  # if v is not in reached dictionary
            reached[edge[1]] = edge[0]
            if edge[1] == dest:  #if the vertex is already the destination
                return get_path(reached, start, dest)  #return the path using get_path from breadth_first_search
            for neighbor in graph.neighbours(edge[1]):  # Loop through neighbors ,w, of v
                events.insert((edge[1], neighbor), time + cost.distance((edge[1], neighbor)))  # add edge and cost to heap
    return get_path(reached, start, dest)  # Return path once search is complete




def load_edmonton_graph(filename):
    """
    Loads the graph of Edmonton from the given file.
    Returns two items
    graph: the instance of the class Graph() corresponding to the
    directed graph from edmonton-roads-2.0.1.txt
    location: a dictionary mapping the identifier of a vertex to
    the pair (lat, lon) of geographic coordinates for that vertex.
    These should be integers measuring the lat/lon in 100000-ths
    of a degree.
    In particular, the return statement in your code should be
    return graph, location
    (or whatever name you use for the variables).
    Note: the vertex identifiers should be converted to integers
    before being added to the graph and the dictionary.
    """
    # read from the file 'filename'
    with open(filename, 'r') as inputFile:
        g = Graph()  # new graph g to add nodes and edges in
        location = {}  # new dictionary containing vertex and (lat,lon)
        # read all the lines
        for line in inputFile:
            CSV_line = line.strip().split(',')  # comma separate entries
            if CSV_line[0]=="V":  #if V is the first part of the line
                g.add_vertex(int(CSV_line[1]))#add vertex
                #add coordinates to vertex in location (multiply lat,lon by 10^5)
                location[int(CSV_line[1])]=[int(float(CSV_line[2])*100000),int(float(CSV_line[3])*100000)]
            elif CSV_line[0]=="E":  # if E is the first part of the line
                g.add_edge((int(CSV_line[1]),int(CSV_line[2])))  # add edge on next inputs

    return g, location  # return graph and location dictionary
    # Create edmonton graph based on txt file and print the edmonton graph's components

class CostDistance:
    """
    A class with a method called distance that will return the Euclidean
    between two given vertices.
    """
    def __init__(self, location):
        """
        Creates an instance of the CostDistance class and stores the
        dictionary "location" as a member of th is class.
        """
        self.location = location

    def distance(self, e):
        """
        Here e is a pair (u,v) of vertices.
        Returns the Euclidean distance between the two vertices u and v.
        """
        coord01, coord02 = e  # first vertex and second vertex
        lat =0  # index of latidude of vertex
        lon = 1  # index of latidude of vertex
        # calculating the euclidean distance
        Euclidean= (((self.location[coord01][lat]-self.location[coord02][lat]))**2+(self.location[coord01][lon]-self.location[coord02][lon])**2)**(1/2.0)
        return Euclidean  # return Euclidean distance


if __name__ == "__main__":
    edmonton_Graph, vertice_Locations = load_edmonton_graph('edmonton-roads-2.0.1.txt')  # Load edmonton_Graph and locations dict
    costObject = CostDistance(vertice_Locations)  # Create costObject for CostDistance

    test, lat01, lon01, lat02, lon02 = input().split()  # user inputes the R, a latidude and longitude for the start and end points
    #Put start and end latidude and longitudes in separate edges
    coord01L = [int(lat01), int(lon01)]
    coord02L = [int(lat02), int(lon02)]

    # set initial closest start and end vertices as non existent and shortest point to 'inf'
    shortest_start, startVertex = float('inf'), -1
    shortest_end, endVertex = float('inf'), -1
    if test == 'R':  # If user entered 'R'
        for vertices, point in vertice_Locations.items():  # Loop through vertices in locations dict
            #Search for the veretices with the closest distance to inputed coordinates
            distance_start = ((coord01L[0]-point[0])**2 + (coord01L[1]-point[1])**2 )**(1/2.0)
            distance_end = ((coord02L[0]-point[0])**2 + (coord02L[1]-point[1])**2 )**(1/2.0)
            if distance_start < shortest_start:
                shortest_start, startVertex = distance_start, vertices
            if distance_end < shortest_end:
                shortest_end, endVertex = distance_end, vertices
        # Return empty path if no path exists
        if startVertex == -1 or endVertex == -1:
            reached_paths = []
        # Use least_cost_path function to return path with now found vertices
        else:
            reached_paths = least_cost_path(edmonton_Graph, startVertex, endVertex, costObject)

        print('N', len(reached_paths))  #print number of waypoints
        for returns in range(len(reached_paths)):
            returnmsg= input()  # User enters 'A' to start receiving each waypoints Coordinates
            if returnmsg =='A':
                print('W', vertice_Locations[reached_paths[returns]][0], vertice_Locations[reached_paths[returns]][1])
            else:
                break
        print('E')  # Prints E when finished returning waypoints or user does not enter 'A'
