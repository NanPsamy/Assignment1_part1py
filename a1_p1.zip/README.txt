Mohammad Kebbi; 1496572
Nan Ponnusamy; 1500538

Assignment 1 part 1:

In this file the following has been implemented:
  server.py: Contains list of functions (below and implementation)
    * The user will enter an input to the stdinput in the form
    'R [start latitude] [start longitude] [end latitude] [end longitude]'
    and program will find the nearest vertices and return the shortest path
    between the two vertices. The program will first return the number of waypoints
    'N [waypoint count]' and will return the waypoints coordinates 'W [lat] [lon]'
    as the user inputs 'A'

  A list of functions to perform the servers tasks:
    * least_cost_path: returns the shorsted cost path for an inserted start and end
    vertex using Dijkstra's Algorithm

    * load_edmonton_graph: Will read the 'edmonton-roads-2.0.1.txt' file, store the
    vertices and their coordinates to the 100000-ths of a degree in a location dictionary, and the edges between
    vertices, and creates a graph based on the edges and verticess

    * CostDistance: Class that stores the location dictionary and holds the
    distance method to return the eudclidiean distance between two vertices


Files imported
 - graph.py
   Our implementation of a directed graph class.

 - breadth_first_search.py
   The assignment does not use a breadth-first search,
   you should use Dijkstra's algorithm. But the get_path
   function from this file might be helpful. *Was imported for the get_path *

  - binary_heap.py
   The binary heap we implemented in class.

Assumptions made: Imported files are from the assignment tar file, and
We assume those files will have not changed since installation

How to run code:
  * Ensure imported files are within the same directory as server.py

  * Enter 'python3 server.py'
  * Enter in the stdinput your R command and start and end coordinates as shown above
  * Respond with 'A' to receive waypoints of paths
